package com.example.mylifebitsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public
class Register extends AppCompatActivity implements View.OnClickListener {
    EditText username, password;
    Button registerlink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        username = (EditText) findViewById(R.id.retusername);
        password = (EditText) findViewById(R.id.retpassword);
        registerlink = (Button) findViewById(R.id.retbreg);

        registerlink.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.retbreg:
                Intent intent = new Intent(this, login.class);
                startActivity(intent);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + v.getId());
        }
    }
}