package com.example.mylifebitsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.internal.location.zzz;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button call;
    Button vault;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        call = (Button) findViewById(R.id.help);
        vault = (Button) findViewById(R.id.vault);

        call.setOnClickListener(this);
        vault.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.help:
                Intent intent = new Intent(this, message_service.class);
                startActivity(intent);
                break;

            case R.id.vault:
                Intent intent2 = new Intent(this, vault_tab.class);
                startActivity(intent2);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + v.getId());
        }

    }
}
