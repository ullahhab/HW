package com.example.mylifebitsapp;

import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.mylifebitsapp.databinding.FragmentVaultTabBinding;

public class upload_layout extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View v;
        v = inflater.inflate(R.layout.upload_layout, container, false);
        Spinner dropdown = (Spinner) v.findViewById(R.id.menu);
        String[] menu = new String[]{"Select Files","Drivers Licence", "Passport", "Social Security"};
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_dropdown_item, menu);
        dropdown.setAdapter(adapter);
        Button upload = (Button) v.findViewById(R.id.file_upload_button);
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = dropdown.getSelectedItem().toString();
                Toast.makeText(getContext(), dropdown.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
            }
        });
        return v;
    }


}
