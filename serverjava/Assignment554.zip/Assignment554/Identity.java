//package CS554;

public enum Identity {
	
	primary,
	backup,
	client,
	
}

