//insert your code in Part_1/p1_opencv_code.cpp
//edit the file extension and web template to match your programing language

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
using namespace cv;
int main()
{
    std::string image_path = samples::findFile("p1_search.jpg");
    Mat img = imread(image_path, IMREAD_COLOR);
    if (img.empty())
    {
        std::cout << "Could not read the image: " << image_path << std::endl;
        return 1;
    }


    int itr;
    int rows = img.rows;
    int columns = img.columns;

    Mat greyMat = cv::cvtColor(colorMat, greyMat, CV_BGR2GRAY);
    itr = 0;
    while (greyMat[itr][columns/2]== 255) {
        itr++;

    }
    int top = itr;
    itr = 0;
    while (greyMat[rows-itr][columns/2] == 255) {
        itr++;

    }
    int bottom = itr;
    itr = 0;

    while (greyMat[row/2][itr] == 255) {
        itr++;

    }
    int left = itr;
    itr = 0;
    while (greyMat[row/2][colums - itr] == 255) {
        itr++;

    }
    
    int right = itr;
    Mat crop[rows-top-bottom][colums-left-right];
    int itrx = 0;
    int itry = 0;
    for (int i = top; i < bottom; i++) {
        for (int j = left; j < right; j++) {
            crop[itrx][itry] = greyMat[i][j];
            itry += 1;
        }
        itrx += 1;

    }

    imwrite("p1_opencv.png", crop);



    return 0;
}