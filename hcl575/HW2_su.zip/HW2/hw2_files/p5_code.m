%insert your code in Part_5/p5_code.cpp
%edit the file extensio

img = imread("p5_search.png");
img = im2gray(img);
[x,y] = size(img);
midx = x/2;
midy = y/2;
true = 1;
itr = 1;
while true
    if img(itr, midy)<=0
        break
    end
    itr = itr + 1;
end
cuttop = itr;
itr = 1;
while true
    if img(x-itr, midy)<=0
        break
    end
    itr = itr+1;
end
cutbot = itr;
itr = 1;
while true
    if img(midx, itr)<=0
        break
    end
    itr = itr+1;
end
cutleft = itr;
itr = 1;
while true
    if img(midx, y-itr)<=0
        break
    end
    itr = itr+1;
end
cutright = itr;
crop = img(cuttop:x - cutbot, cutleft:y-cutright);

grid = imread("p5_search.png");
grid = grid(cuttop:x - cutbot, cutleft:y-cutright);
[x,y] = size(grid);


%Grab x's TO grab an A I'm gonna crop it using hard code
X = crop(272+4:272+64, 5:63);

%Grab y's 
O = crop(5:64,5:59);

%Grab dot
dot = crop(5:64, 126+4+1:126+4+59);

bi_d = im2bw(crop,0.5);
bi_d = ~bi_d;
bse_d = im2bw(dot,0.5);
bse_d = ~bse_d;

bi_x = im2bw(crop,0.5);
bi_x = ~bi_x;
bse_x = im2bw(X,0.5);
bse_x = ~bse_x;

bi_o = im2bw(crop,0.5);
bi_o = ~bi_o;
bse_o = im2bw(O,0.5);
bse_o = ~bse_o;

er_x = imerode(bi_x,bse_x);
dil_x = imdilate(er_x,bse_x);

er_o = imerode(bi_o,bse_o);
dil_o = imdilate(er_o,bse_o);

er_d = imerode(bi_d,bse_d);
dil_d = imdilate(er_d,bse_d);


for i = 1:x
    for j = 1:y
        %grid(i,j)
        if dil_o(i,j) == 1
            grid(i,j,1:3) = int16([255,0,0]);
        end
        if dil_d(i,j) == 1
            grid(i,j,1:3) = [0,255,0];
        end
        if dil_x(i,j) == 1
            grid(i,j,1:3) = [0,0,255];
        end
    end
end

imwrite(grid,"coloredy.png");