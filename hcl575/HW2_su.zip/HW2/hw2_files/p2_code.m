%insert your code in Part_2/p2_code.cpp
%edit the file extension and web template to match your programing language

img = imread("p2_search.png");
img = im2gray(img);
[x,y] = size(img);
midx = x/2;
midy = y/2;
true = 1;
itr = 1;
while true
    if img(itr, midy)<=0
        break
    end
    itr = itr + 1;
end
cuttop = itr;
itr = 1;
while true
    if img(x-itr, midy)<=0
        break
    end
    itr = itr+1;
end
cutbot = itr;
itr = 1;
while true
    if img(midx, itr)<=0
        break
    end
    itr = itr+1;
end
cutleft = itr;
itr = 1;
while true
    if img(midx, y-itr)<=0
        break
    end
    itr = itr+1;
end
cutright = itr;
crop = img(cuttop:x - cutbot, cutleft:y-cutright);


%Seperation part!
blackx =1;
blacky = 1;

% This code will get us to whites 
while 1
   crop(blackx ,blacky);
   if crop(blackx , blacky) > 0
       break
   end
   blackx = blackx+1;
   blacky = blacky+1;
end

%Find the length and width of the box
b_height = blackx;
b_width = blacky;

%length code 
while 1
    if crop(b_height,b_width)<=0
        break
    end
    b_height  = b_height+1;
end
b_height = b_height-5;
%width
while 1
    if crop(blackx,b_width) <=0
        break
    end
    b_width = b_width+1;
end
b_width = b_width-5;

%Now the main part goes
%GRID is for grid image 
%symbol is for symbol image

row =blackx;  %These will help us track the row
add_symx = 4;
[r,c] = size(crop);
GRID = crop;
symbol= 255*ones(r,c);
while row+b_height-4<= r
    column = blacky; %These will help us track box
    %add column end
    add_symy =4;
    while column+b_width-2 <=c
        symbol(row:b_height+add_symx-4,column:b_width+add_symy-2) = crop(row:b_height+add_symx-4,column:b_width+add_symy-2);
        GRID(row:b_height+add_symx-4,column:b_width+add_symy-2) =255*ones(b_height-4,b_width-2);
        column = column+b_width+blacky-1;
        add_symy = column-1;
        
    end
    row = row + b_height+blackx-1;
    add_symx = row-1;
end
imwrite(GRID, 'grid.png');
imwrite(symbol, 'symbol.png');
%GRID(row:b_height+row-1,column+b_width+blacky-1:blacky+b_width+b_width+column-2) =255*ones(64,59);
%maths that would go is 
    
