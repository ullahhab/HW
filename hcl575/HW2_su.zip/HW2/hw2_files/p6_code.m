%insert your code in Part_6/p6_code.cpp
%edit the file extension and web template to match your programing language




img = imread("p6_search.png");
img = im2gray(img);
[x,y] = size(img);
midx = x/2;
midy = y/2;
true = 1;
itr = 1;
while true
    if img(itr, midy)<=0
        break
    end
    itr = itr + 1;
end
cuttop = itr;
itr = 1;
while true
    if img(x-itr, midy)<=0
        break
    end
    itr = itr+1;
end
cutbot = itr;
itr = 1;
while true
    if img(midx, itr)<=0
        break
    end
    itr = itr+1;
end
cutleft = itr;
itr = 1;
while true
    if img(midx, y-itr)<=0
        break
    end
    itr = itr+1;
end
cutright = itr;
crop = img(cuttop:x - cutbot, cutleft:y-cutright);

grid = imread("p6_search.png");
grid = grid(cuttop:x - cutbot, cutleft:y-cutright);
[x,y] = size(grid);

symbol = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/symbol.png');
figure; imshow(symbol)
%Grab x's TO grab an A I'm gonna crop it using hard code
X = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/X.png');

%Grab y's 
O = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/O.png');

%Grab dot
dot = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/dot.png');

slash = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/slash.png');

plus = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/plus.png');

b_s = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/backslash.png');

b_l = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/vertical.png');

b_h = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/horizontal.png');

bi_d = im2bw(crop,0.5);
bi_d = ~bi_d;
bse_d = im2bw(dot,0.5);
bse_d = ~bse_d;
%figure; imshow(bi_d);

bi_x = im2bw(crop,0.5);
bi_x = ~bi_x;
bse_x = im2bw(X,0.5);
bse_x = ~bse_x;
%figure; imshow(bi_x);

bi_o = im2bw(crop,0.5);
bi_o = ~bi_o;
bse_o = im2bw(O,0.5);
bse_o = ~bse_o;
%figure; imshow(bi_o);

bi_s = im2bw(crop,0.5);
bi_s = ~bi_s;
bse_s = im2bw(slash,0.5);
bse_s = ~bse_s;
%figure; imshow(bi_s);

bi_p = im2bw(crop,0.5);
bi_p = ~bi_p;
bse_p = im2bw(plus,0.5);
bse_p = ~bse_p;
%figure; imshow(bi_p);

bi_bs = im2bw(crop,0.5);
bi_bs = ~bi_bs;
bse_bs = im2bw(b_s,0.5);
bse_bs = ~bse_bs;
%figure; imshow(bi_bs);


bi_h = im2bw(crop,0.5);
bi_h = ~bi_h;
bse_h = im2bw(b_h,0.5);
bse_h = ~bse_h;
%figure; imshow(bi_h);


bi_l = im2bw(crop,0.5);
bi_l = ~bi_l;
bse_l = im2bw(b_l,0.5);
bse_l = ~bse_l;
%figure; imshow(bi_l);

er_x = imerode(bi_x,bse_x);
dil_x = imdilate(er_x,bse_x);

er_o = imerode(bi_o,bse_o);
dil_o = imdilate(er_o,bse_o);

er_d = imerode(bi_d,bse_d);
dil_d = imdilate(er_d,bse_d);

er_p = imerode(bi_p,bse_p);
dil_p = imdilate(er_p,bse_p);

er_s = imerode(bi_s,bse_s);
dil_s = imdilate(er_s,bse_s);

er_bs = imerode(bi_bs,bse_bs);
dil_bs = imdilate(er_bs,bse_bs);

er_l = imerode(bi_l,bse_l);
dil_l = imdilate(er_l,bse_l);

er_h = imerode(bi_h,bse_h);
dil_h = imdilate(er_h,bse_h);




for i = 1:x
    for j = 1:y
        %grid(i,j)
        if dil_o(i,j) == 1
            grid(i,j,1:3) = int16([255,0,0]);
        end
        if dil_d(i,j) == 1
            grid(i,j,1:3) = [0,255,0];
        end
        if dil_x(i,j) == 1
            grid(i,j,1:3) = [0,0,255];
        end
        if dil_s(i,j) == 1
            grid(i,j,1:3) = [0,255,255];
        end
        if dil_bs(i,j) == 1
            grid(i,j,1:3) = [255,0,255];
        end
        if dil_p(i,j) == 1
            grid(i,j,1:3) = [100,15,255];
        end
        if dil_l(i,j) == 1
            grid(i,j,1:3) = [10,150,255];
        end
        if dil_h(i,j) == 1
            grid(i,j,1:3) = [10,10,255];
        end
    end
end

imwrite(grid,"coloredz.png");