%insert your code in Part_9/p9_code.cpp
%edit the file extension and web template to match your programing language



img = imread("p9_search.png");
img = im2gray(img);
[x,y] = size(img);
midx = x/2;
midy = y/2;
true = 1;
itr = 1;
while true
    if img(itr, midy)<=0
        break
    end
    itr = itr + 1;
end
cuttop = itr;
itr = 1;
while true
    if img(x-itr, midy)<=0
        break
    end
    itr = itr+1;
end
cutbot = itr;
itr = 1;
while true
    if img(midx, itr)<=0
        break
    end
    itr = itr+1;
end
cutleft = itr;
itr = 1;
while true
    if img(midx, y-itr)<=0
        break
    end
    itr = itr+1;
end
cutright = itr;
crop = img(cuttop:x - cutbot, cutleft:y-cutright);
imshow(crop)


gray = im2gray(crop);
boxlength = 1;

while 1
    if crop(boxlength+5,5)==0
        break
    end
    boxlength=boxlength+1;
end

boxlength = boxlength+4;
boxwidth = 1;

while 1
    if crop(5,5+boxwidth)==0
        break
    end
    boxwidth=boxwidth+1;
end

boxwidth = boxwidth+4;

grid = imread("p8_search.png");
grid = grid(cuttop:x - cutbot, cutleft:y-cutright);
[x,y] = size(grid);

symbol = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/symbol.png');
figure; imshow(symbol)
%Grab x's TO grab an A I'm gonna crop it using hard code
X = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/X.png');

%Grab y's 
O = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/O.png');

%Grab dot
dot = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/dot.png');

slash = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/slash.png');

plus = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/plus.png');

b_s = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/backslash.png');

b_l = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/vertical.png');

b_h = imread('C:/Users/shaik/OneDrive/Documents/MATLAB/HW2/Symbol_Cutouts/horizontal.png');

v_l = zeros(midx*2,4);
h_l = zeros(4,midy);

bi_vl = im2bw(crop,0.5);
bi_vl = ~bi_vl;
bse_vl = im2bw(v_l,0.5);
bse_vl = ~bse_vl;

bi_hl = im2bw(crop,0.5);
bi_hl = ~bi_hl;
bse_hl = im2bw(h_l,0.5);
bse_hl = ~bse_hl;

er_vl = imerode(bi_vl,bse_vl);
dil_vl = imdilate(er_vl,bse_vl);

er_hl = imerode(bi_hl,bse_hl);
dil_hl = imdilate(er_hl,bse_hl);


bi_d = im2bw(crop,0.5);
bi_d = ~bi_d;
bse_d = im2bw(dot,0.5);
bse_d = ~bse_d;
%figure; imshow(bi_d);

bi_x = im2bw(crop,0.5);
bi_x = ~bi_x;
bse_x = im2bw(X,0.5);
bse_x = ~bse_x;
%figure; imshow(bi_x);

bi_o = im2bw(crop,0.5);
bi_o = ~bi_o;
bse_o = im2bw(O,0.5);
bse_o = ~bse_o;
%figure; imshow(bi_o);

bi_s = im2bw(crop,0.5);
bi_s = ~bi_s;
bse_s = im2bw(slash,0.5);
bse_s = ~bse_s;
%figure; imshow(bi_s);

bi_p = im2bw(crop,0.5);
bi_p = ~bi_p;
bse_p = im2bw(plus,0.5);
bse_p = ~bse_p;
%figure; imshow(bi_p);

bi_bs = im2bw(crop,0.5);
bi_bs = ~bi_bs;
bse_bs = im2bw(b_s,0.5);
bse_bs = ~bse_bs;
%figure; imshow(bi_bs);


bi_h = im2bw(crop,0.5);
bi_h = ~bi_h;
bse_h = im2bw(b_h,0.5);
bse_h = ~bse_h;
%figure; imshow(bi_h);


bi_l = im2bw(crop,0.5);
bi_l = ~bi_l;
bse_l = im2bw(b_l,0.5);
bse_l = ~bse_l;
%figure; imshow(bi_l);

er_x = imerode(bi_x,bse_x);
dil_x = imdilate(er_x,bse_x);

er_o = imerode(bi_o,bse_o);
dil_o = imdilate(er_o,bse_o);

er_d = imerode(bi_d,bse_d);
dil_d = imdilate(er_d,bse_d);

er_p = imerode(bi_p,bse_p);
dil_p = imdilate(er_p,bse_p);

er_s = imerode(bi_s,bse_s);
dil_s = imdilate(er_s,bse_s);


er_bs = imerode(bi_bs,bse_bs);
dil_bs = imdilate(er_bs,bse_bs);


er_l = imerode(bi_l,bse_l);
dil_l = imdilate(er_l,bse_l);

er_h = imerode(bi_h,bse_h);
dil_h = imdilate(er_h,bse_h);

itr_x=1;
itr_bs=1;
itr_d=1;
itr_s=1;
itr_h=1;
itr_l=1;
itr_p=1;
itr_o=1;

figure; imshow(dil_bs)

flag = 0;


for i = 1:x
    for j = 1:y
%         %grid(i,j)
        if dil_s(i,j) == 1 && (dil_hl(i,j) == 0) && (dil_vl(i,j)==0)
           [i,j] 
           grid(i-11:i+7,j-16:j+20)=255*ones(19,37);
           dil_bs(i-10:i+44,j-30:j+24)=zeros(55);
           position_s(itr_s,1:2) = [j-40,i-40];
           flag=1;
           break
        end
    end
    if flag == 1
        break
    end
    
end

for i = 1:x
    for j = 1:y
        if dil_o(i,j) == 1
           grid(i-10:i+33,j-10:j+33)=255*ones(44);
           dil_o(i-20:i+53,j-25:j+43)=zeros(64,69);
           position_o(itr_o,1:2) = [j-25,i-55];
           flag=1;
           break
        end
    end
    if flag == 1
        break
    end
    
end
for i = 1:x
    for j = 1:y
        if dil_d(i,j) == 1
           grid(i-10:i+33,j-10:j+30)=255*ones(44,41);
           dil_d(i-16:i+43,j-16:j+43)=zeros(60);
           position_d(itr_d,1:2) = [j-25,i-55];
           flag=1;
           break
        end
    end
    if flag == 1
        break
    end
    
end
for i = 1:x
    for j = 1:y
        if dil_x(i,j) == 1
           grid(i-10:i+33,j-10:j+33)=255*ones(44);
           dil_x(i-10:i+33,j-10:j+33)=zeros(44);
           position_x(itr_x,1:2) = [j-25,i-55];
           flag=1;
           break
        end
    end
    if flag == 1
        break
    end
    
 end

 for i = 1:x
    for j = 1:y
        if (dil_bs(i,j) == 1) && (dil_hl(i,j) == 0) && (dil_vl(i,j)==0)
           [i,j] 
           grid(i-10:i+44,j-10:j+38)=255*ones(55,49);
           dil_bs(i-10:i+44,j-10:j+44)=zeros(55);
           
           position_bs(itr_bs,1:2) = [j-25,i-55];
           flag=1;
           break
        end
    end
    if flag == 1
        break
    end
    
end
%            itr_o = itr_o+1;
%         end

%            itr_d = itr_d+1;
%         end

%            itr_x = itr_x+1;
%         end
% 
%         if (dil_bs(i,j) == 1) && (dil_hl(i,j) == 0) && (dil_vl(i,j)==0)
%            [i,j] 
%            grid(i-10:i+44,j-10:j+38)=255*ones(55,49);
%            dil_bs(i-10:i+44,j-10:j+44)=zeros(55);
%            
%            position_bs(itr_bs,1:2) = [j-25,i-55];
%            itr_bs = itr_bs+1;
%         end
%         if (dil_p(i,j) == 1) && (dil_hl(i,j) == 0) && (dil_vl(i,j)==0)
%            grid(i-14:i+29,j-10:j+28)=255*ones(44,39);
%            dil_p(i-10:i+43,j-10:j+43)=zeros(54);
%            
%            position_p(itr_p,1:2) = [j-25,i-55];
%            itr_p = itr_p+1;
%         end
% %         if (dil_l(i,j) == 1) && (dil_hl(i,j) == 0) && (dil_vl(i,j)==0)
% %            grid(i-10:i+13,j-10:j+32)=255*ones(24,43);
% %            dil_l(i-20:i+43,j-20:j+43)=zeros(64,64);
% %            
% %            position_l(itr,1:2) = [j-25,i-55];
% %            itr_l = itr_l+1;
% %         end
%         if (dil_h(i,j) == 1) && (dil_hl(i,j) == 0) && (dil_vl(i,j)==0)
%            grid(i-10:i+29,j-10:j+33)=255*ones(40,44);
%            dil_h(i-10:i+33,j-10:j+33)=zeros(44);
%            
%            position_h(itr_h,1:2) = [j-25,i-55];
%            itr_h = itr_h+1;
%        end
%      end
% end
 L = insertText(grid, position_s, '/', 'FontSize', 60, 'BoxColor','white','BoxOpacity',0, 'TextColor','blue');

 imshow(L)
 imwrite(grid,'first_color.png')
