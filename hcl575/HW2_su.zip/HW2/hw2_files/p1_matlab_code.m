%insert your code in Part_1/p1_matlab_code.m

img = imread("p1_search.png");
img = im2gray(img);
[x,y] = size(img);
midx = x/2;
midy = y/2;
true = 1;
itr = 1;
while true
    if img(itr, midy)<=0
        break
    end
    itr = itr + 1;
end
cuttop = itr;
itr = 1;
while true
    if img(x-itr, midy)<=0
        break
    end
    itr = itr+1;
end
cutbot = itr;
itr = 1;
while true
    if img(midx, itr)<=0
        break
    end
    itr = itr+1;
end
cutleft = itr;
itr = 1;
while true
    if img(midx, y-itr)<=0
        break
    end
    itr = itr+1;
end
cutright = itr;
crop = img(cuttop:x - cutbot, cutleft:y-cutright);
imshow(crop)
imwrite(crop, 'croped_image.png');
