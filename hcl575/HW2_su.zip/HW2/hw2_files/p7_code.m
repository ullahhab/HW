
%RGB = insertText(I, [23, 45], 'x', 'FontSize', 60, 'BoxColor','white','BoxOpacity',0, 'TextColor','black')


img = imread("p7_search.png");
img = im2gray(img);
[x,y] = size(img);
midx = x/2;
midy = y/2;
true = 1;
itr = 1;
while true
    if img(itr, midy)<=0
        break
    end
    itr = itr + 1;
end
cuttop = itr;
itr = 1;
while true
    if img(x-itr, midy)<=0
        break
    end
    itr = itr+1;
end
cutbot = itr;
itr = 1;
while true
    if img(midx, itr)<=0
        break
    end
    itr = itr+1;
end
cutleft = itr;
itr = 1;
while true
    if img(midx, y-itr)<=0
        break
    end
    itr = itr+1;
end
cutright = itr;
crop = img(cuttop:x - cutbot, cutleft:y-cutright);

grid = imread("p7_search.png");
grid = grid(cuttop:x - cutbot, cutleft:y-cutright);
[x,y] = size(grid);
grid = im2gray(grid);



X = crop(272+4:272+64, 5:63);

bi_x = im2bw(crop,0.5);
bi_x = ~bi_x;
bse_x = im2bw(X,0.5);
bse_x = ~bse_x;

er_x = imerode(bi_x,bse_x);
dil_x = imdilate(er_x,bse_x);




%create y
Y = insertText(grid, [250,110], 'y', 'FontSize', 60, 'BoxColor','white','BoxOpacity',0, 'TextColor','black');
%Y = Y(50:126,190:250);
Y = im2bw(Y,0.5);

itr=1;

for i = 1:x
    for j = 1:y
        %dil_x(i,j)
       if dil_x(i, j) == 1
           grid(i-10:i+33,j-10:j+33)=255*ones(44);
           dil_x(i-10:i+33,j-10:j+33)=zeros(44);
           %grid = insertText(grid, [j-30,i-50], 'y', 'FontSize', 60, 'BoxColor','white','BoxOpacity',0, 'TextColor','black');
           position(itr,1:2) = [j-25,i-55];
           itr = itr+1;
           
       end
    end
end

%grid = im2bw(grid);
grid = insertText(grid, position, 'y', 'FontSize', 60, 'BoxColor','white','BoxOpacity',0, 'TextColor','black','Font','Segoe UI Semibold');
imwrite(grid,'gridx_to_y.png');

        
